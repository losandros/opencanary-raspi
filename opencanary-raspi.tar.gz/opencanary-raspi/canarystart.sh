cd canary-env
./bin/opencanaryd --dev
