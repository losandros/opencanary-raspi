#!/bin/bash
cd /home/pi
echo "updating raspian"
sudo apt update
sudo apt full-upgrade 
echo "installing opencanary pre-requisites"
sudo apt install python-dev python-pip python-virtualenv libssl-dev libffi-dev libpcap-dev libpq-dev samba
echo "creating virtualenv"
mkdir canary-env
virtualenv -p python2 canary-env
source ./canary-env/bin/activate
echo "installing all pip pre-requisites"
pip install --upgrade pip setuptools
pip install rdpy
pip install scapy pcapy
echo "downloading patron-it opencanary fork"
git clone https://github.com/patron-it/opencanary
echo "changing iptables log-level from warning to info"
cd /home/pi/opencanary/opencanary/modules
mv portscan.py portscan.py.original
cat portscan.py.original | sed s/"--log-level=warning"/"--log-level=info"/g >> portscan.py
cd ../../
echo "installing opencanary via pip"
pip install opencanary
sudo mkdir -p /etc/opencanaryd
sudo cp opencanary.conf /etc/opencanaryd/
cp bin/opencanary.tac /home/pi/canary-env/bin/opencanary.tac
echo "creating empty logfile in/var/tmp/"
sudo touch /var/tmp/opencanary.log
sudo touch /var/tmp/opencanary-up.log
echo "copying systemd service"
sudo cp opencanary.service /lib/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable opencanary.service
echo "copying opencanary-heartbeat timer and service"
cp /home/pi/opencanary-raspi/canary-up.sh /home/pi/canary-env/bin/
sudo cp opencanary-heartbeat.* /lib/systemd/system/
sudo systemctl enable opencanary-heartbeat.timer
echo "Starting opencanary service and opencanary-heartbeat"
sudo service opencanary start
sudo systemctl start opencanary-heartbeat.timer
